from distutils.version import StrictVersion

VERSION = StrictVersion('0.0.0')